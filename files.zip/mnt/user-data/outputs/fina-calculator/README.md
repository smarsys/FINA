# 🏊 Calculateur Points FINA - Lausanne Aquatique

Application web progressive (PWA) pour calculer les points FINA en natation.

## ✨ Fonctionnalités

- ✅ Calcul bidirectionnel : **Temps → Points** et **Points → Temps**
- ✅ Support **Homme / Femme**
- ✅ Bassins **25m** et **50m**
- ✅ Toutes les nages : Libre, Dos, Brasse, Papillon, 4 Nages
- ✅ Distances : 50m, 100m, 200m, 400m, 800m, 1500m
- ✅ **Installable** comme application mobile (PWA)
- ✅ Fonctionne **hors ligne**
- ✅ Données officielles **World Aquatics 2024**

## 📦 Fichiers

```
fina-calculator/
├── index.html           # Interface utilisateur
├── app.js              # Logique de calcul
├── fina-times.json     # Temps de base FINA (H/F)
├── manifest.json       # Configuration PWA
├── service-worker.js   # Cache et mode offline
├── icon-192.png        # Icône 192x192
├── icon-512.png        # Icône 512x512
└── README.md           # Ce fichier
```

## 🚀 Déploiement sur Jelastic Cloud (Infomaniak)

### Méthode 1 : Via Archive ZIP

1. **Créer un environnement**
   - Connectez-vous à https://app.jelastic.infomaniak.com
   - Cliquez sur **"New Environment"**
   - Choisissez **Apache** (configuration minimale : 128MB RAM)
   - Nommez l'environnement : `fina-calculator`
   - Cliquez sur **"Create"**

2. **Préparer le ZIP**
   ```bash
   # Créez un fichier ZIP avec tous les fichiers
   zip -r fina-calculator.zip *
   ```

3. **Déployer**
   - Dans Jelastic, cliquez sur **"Deployment Manager"**
   - Cliquez sur **"Upload"** et sélectionnez votre ZIP
   - Une fois uploadé, cliquez sur **"Deploy to..."**
   - Sélectionnez votre serveur Apache
   - Context : `/` (racine)
   - Cliquez sur **"Deploy"**

4. **Accéder à l'application**
   - Utilisez l'URL fournie : `https://fina-calculator-xxx.jlc.infomaniak.com`

### Méthode 2 : Via Git

1. **Créer un repository Git**
   ```bash
   git init
   git add .
   git commit -m "Initial commit - Calculateur FINA"
   git remote add origin https://github.com/votre-compte/fina-calculator.git
   git push -u origin main
   ```

2. **Déployer depuis Git**
   - Dans Jelastic, **Deployment Manager** → **Add** → **Git/SVN**
   - URL : `https://github.com/votre-compte/fina-calculator.git`
   - Branch : `main`
   - Cliquez sur **"Add"** puis **"Deploy to..."**

### Méthode 3 : Via File Manager

1. **Accéder au File Manager**
   - Dans Jelastic, cliquez sur **"Config"** de votre serveur
   - Naviguez vers : `webroot/ROOT/`

2. **Upload les fichiers**
   - Supprimez le contenu par défaut
   - Uploadez tous vos fichiers directement

## 📱 Installation sur mobile

### Android (Chrome)
1. Ouvrez l'application dans Chrome
2. Menu (⋮) → **"Ajouter à l'écran d'accueil"**

### iOS (Safari)
1. Ouvrez l'application dans Safari
2. Bouton partage → **"Sur l'écran d'accueil"**

## 🔧 Mise à jour de l'application

### Modifier les temps de base

1. Éditez le fichier `fina-times.json`
2. Modifiez les valeurs dans la structure :
   ```json
   {
     "25m": {
       "male": { ... },
       "female": { ... }
     },
     "50m": {
       "male": { ... },
       "female": { ... }
     }
   }
   ```

3. **Important** : Changez la version du cache dans `service-worker.js` :
   ```javascript
   const CACHE_NAME = 'fina-calculator-v2'; // Incrémentez le numéro
   ```

4. Redéployez l'application

### Sur Jelastic
- **Via ZIP** : Uploadez un nouveau ZIP et redéployez
- **Via Git** : Push vos modifications et cliquez sur **"Re-deploy"**
- **Via File Manager** : Éditez directement le fichier

### Tester les changements
- Ouvrez l'application
- Appuyez sur **Ctrl + Shift + R** (ou Cmd + Shift + R sur Mac)
- Cela force le rechargement et ignore le cache

## 🎨 Personnalisation

### Changer les couleurs
Dans `index.html`, modifiez les couleurs dans le `<style>` :
```css
background: linear-gradient(135deg, #0066cc 0%, #004999 100%);
/* Remplacez #0066cc par votre couleur */
```

### Ajouter le logo
1. Créez des images PNG 192x192 et 512x512 pixels
2. Remplacez `icon-192.png` et `icon-512.png`
3. Design recommandé :
   - Fond bleu Lausanne Aquatique (#0066cc)
   - Logo "LA" ou logo officiel du club

## 📊 Structure des données FINA

Les temps de base sont en **secondes** et suivent le format :
```json
{
  "bassin": {
    "genre": {
      "nage": {
        "distance": temps_en_secondes
      }
    }
  }
}
```

Exemple :
```json
{
  "25m": {
    "male": {
      "freestyle": {
        "50": 20.16,
        "100": 44.84
      }
    }
  }
}
```

## 🧮 Formule de calcul

**Points → Temps :**
```
Points = 1000 × (Temps_Base / Temps_Nageur)³
```

**Temps → Points :**
```
Temps = Temps_Base / (Points / 1000)^(1/3)
```

## 📝 Support

Pour toute question ou problème :
- Vérifiez que tous les fichiers sont bien uploadés
- Testez en mode navigation privée
- Vérifiez la console du navigateur (F12)
- Forcez le rechargement (Ctrl + Shift + R)

## 📄 Licence

Usage personnel - Lausanne Aquatique
Données FINA/World Aquatics © 2024

---

Développé pour faciliter l'entraînement et la planification en natation 🏊‍♂️
