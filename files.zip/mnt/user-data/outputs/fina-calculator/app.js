// Variables globales
let currentMode = 'timeToPoints';
let currentGender = 'male';
let finaData = null;

// Charger les données FINA
fetch('fina-times.json')
    .then(response => response.json())
    .then(data => {
        finaData = data;
        console.log('Données FINA chargées');
    })
    .catch(error => console.error('Erreur chargement FINA:', error));

// Gestion des boutons de mode
document.querySelectorAll('.mode-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.mode-btn').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        currentMode = this.dataset.mode;
        
        const timeInput = document.getElementById('timeInputGroup');
        const pointsInput = document.getElementById('pointsInputGroup');
        const resultDiv = document.getElementById('result');
        const errorDiv = document.getElementById('error');
        
        if (currentMode === 'timeToPoints') {
            timeInput.classList.remove('hidden');
            pointsInput.classList.add('hidden');
        } else {
            timeInput.classList.add('hidden');
            pointsInput.classList.remove('hidden');
        }
        
        resultDiv.classList.add('hidden');
        errorDiv.classList.add('hidden');
    });
});

// Gestion des boutons de genre
document.querySelectorAll('.gender-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.gender-btn').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        currentGender = this.dataset.gender;
        
        // Réinitialiser les résultats
        document.getElementById('result').classList.add('hidden');
        document.getElementById('error').classList.add('hidden');
    });
});

// Gestion du formulaire
document.getElementById('calculatorForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const pool = document.getElementById('pool').value;
    const stroke = document.getElementById('stroke').value;
    const distance = document.getElementById('distance').value;
    
    hideMessages();
    
    if (!finaData) {
        showError('Données FINA non chargées. Veuillez rafraîchir la page.');
        return;
    }
    
    if (currentMode === 'timeToPoints') {
        calculatePoints(pool, stroke, distance, currentGender);
    } else {
        calculateTime(pool, stroke, distance, currentGender);
    }
});

// Calcul Points depuis Temps
function calculatePoints(pool, stroke, distance, gender) {
    const minutes = parseInt(document.getElementById('minutes').value) || 0;
    const seconds = parseFloat(document.getElementById('seconds').value) || 0;
    const totalSeconds = minutes * 60 + seconds;
    
    if (totalSeconds <= 0) {
        showError('Veuillez entrer un temps valide');
        return;
    }
    
    const baseTime = getBaseTime(pool, stroke, distance, gender);
    
    if (!baseTime) {
        showError('Combinaison non disponible dans les tables FINA');
        return;
    }
    
    const points = Math.round(1000 * Math.pow(baseTime / totalSeconds, 3));
    
    showResult(`${points} points`, 'Points FINA');
}

// Calcul Temps depuis Points
function calculateTime(pool, stroke, distance, gender) {
    const points = parseInt(document.getElementById('points').value);
    
    if (!points || points <= 0) {
        showError('Veuillez entrer un nombre de points valide');
        return;
    }
    
    const baseTime = getBaseTime(pool, stroke, distance, gender);
    
    if (!baseTime) {
        showError('Combinaison non disponible dans les tables FINA');
        return;
    }
    
    const totalSeconds = baseTime / Math.pow(points / 1000, 1/3);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = (totalSeconds % 60).toFixed(2);
    
    showResult(`${minutes}:${seconds.padStart(5, '0')}`, 'Temps requis');
}

// Récupérer le temps de base
function getBaseTime(pool, stroke, distance, gender) {
    try {
        const key = `${pool}m`;
        if (!finaData[key] || !finaData[key][gender] || !finaData[key][gender][stroke]) {
            return null;
        }
        return finaData[key][gender][stroke][distance];
    } catch (error) {
        console.error('Erreur récupération temps de base:', error);
        return null;
    }
}

// Afficher le résultat
function showResult(value, label) {
    const resultDiv = document.getElementById('result');
    const resultLabel = document.getElementById('resultLabel');
    const resultValue = document.getElementById('resultValue');
    
    resultLabel.textContent = label;
    resultValue.textContent = value;
    resultDiv.classList.remove('hidden');
}

// Afficher une erreur
function showError(message) {
    const errorDiv = document.getElementById('error');
    errorDiv.textContent = message;
    errorDiv.classList.remove('hidden');
}

// Cacher les messages
function hideMessages() {
    document.getElementById('result').classList.add('hidden');
    document.getElementById('error').classList.add('hidden');
}

// Gestion de l'installation PWA
let deferredPrompt;

window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    document.getElementById('installPrompt').classList.remove('hidden');
});

document.getElementById('installBtn').addEventListener('click', async () => {
    if (!deferredPrompt) {
        return;
    }
    
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    
    if (outcome === 'accepted') {
        document.getElementById('installPrompt').classList.add('hidden');
    }
    
    deferredPrompt = null;
});

// Mise à jour des distances disponibles selon la nage
document.getElementById('stroke').addEventListener('change', function() {
    const stroke = this.value;
    const distanceSelect = document.getElementById('distance');
    
    // Réinitialiser les options
    distanceSelect.innerHTML = '';
    
    let distances = [];
    
    switch(stroke) {
        case 'freestyle':
            distances = ['50', '100', '200', '400', '800', '1500'];
            break;
        case 'backstroke':
        case 'breaststroke':
        case 'butterfly':
            distances = ['50', '100', '200'];
            break;
        case 'medley':
            distances = ['100', '200', '400'];
            break;
    }
    
    distances.forEach(dist => {
        const option = document.createElement('option');
        option.value = dist;
        option.textContent = dist + 'm';
        distanceSelect.appendChild(option);
    });
});

// Mise à jour initiale des distances
document.getElementById('stroke').dispatchEvent(new Event('change'));
